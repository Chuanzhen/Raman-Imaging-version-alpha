// focus_img.cpp : ���� DLL Ӧ�ó���ĵ���������
//

#define DLL_IMPLEMENT  

#include <math.h>
#include <stdio.h>
#include "focus_img.h"

double sum_square(unsigned char *pBuffer, int width, int height)
{
	/*
	Mat frame;
	IplImage *head = cvCreateImageHeader(cvSize(width, height), depth_bit, 1);
	cvSetData(head, _pBuffer, width);
	frame = cvarrToMat(head);

	Mat gray;
	cvtColor(frame, gray, CV_RGB2GRAY);
	double sum = 0;

	for (int i = 0; i < (gray.rows - 2); i++)
	{
		for (int j = 0; j < gray.cols; j++)
		{
			double temp1 = gray.at<uchar>(i, j);
			double temp2 = gray.at<uchar>(i + 2, j);
			sum = pow((double(temp1) - double(temp2)), 2) + sum;
		}
	}
	cvReleaseImage(&head);*/

	double sum = 0;

	for (int i = 0; i < width-2; i++)
	{
		for (int j = 0; j < height; j++)
		{
			int temp = int(pBuffer[j*width + i]) - int(pBuffer[j*width + i+ 2]);
			sum = pow(double(temp), 2) + sum;
		}
	}

	return 1 / sum;
}